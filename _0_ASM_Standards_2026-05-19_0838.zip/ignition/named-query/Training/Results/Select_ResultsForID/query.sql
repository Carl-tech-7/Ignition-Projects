SELECT *
FROM results
WHERE user_id = :userID
