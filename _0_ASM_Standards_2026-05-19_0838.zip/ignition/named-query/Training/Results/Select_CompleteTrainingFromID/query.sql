SELECT DISTINCT module_id
FROM results
WHERE user_id = :userID and completed = TRUE