INSERT INTO results (user_id,submitted_date, module_id, completed, result)
VALUES (:userID, NOW(), :moduleID, TRUE, 100)