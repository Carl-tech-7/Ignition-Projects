UPDATE users
SET first_name = :firstName, last_name = :lastName
WHERE id = :index