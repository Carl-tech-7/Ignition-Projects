SELECT *
FROM users
WHERE industry_number = :industryNumber
