INSERT INTO users (industry_number, first_name, last_name)
VALUES (:industryNumber,:firstName,:lastName)