SELECT 
	*
FROM questions
where module_id = :moduleID and configured = :showConfigured