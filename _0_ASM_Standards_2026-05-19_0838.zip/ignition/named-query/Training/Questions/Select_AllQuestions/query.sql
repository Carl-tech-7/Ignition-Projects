SELECT 
	*
FROM questions
