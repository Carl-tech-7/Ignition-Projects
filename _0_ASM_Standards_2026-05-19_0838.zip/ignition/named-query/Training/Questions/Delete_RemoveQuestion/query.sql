DELETE FROM questions
WHERE id = :index