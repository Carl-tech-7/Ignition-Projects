UPDATE questions
SET  {myQuery}
WHERE id = :index