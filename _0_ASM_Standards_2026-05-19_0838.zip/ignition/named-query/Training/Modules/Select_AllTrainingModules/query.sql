SELECT 
	*,
	false as completed
FROM modules
WHERE discipline = :disciplineType OR discipline = 'All'
ORDER BY id