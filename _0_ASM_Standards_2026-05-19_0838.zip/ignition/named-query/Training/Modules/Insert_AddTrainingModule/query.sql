INSERT INTO modules (id,module_name, description, discipline)
VALUES (:index,'New Test Module','Describe your test module','All')