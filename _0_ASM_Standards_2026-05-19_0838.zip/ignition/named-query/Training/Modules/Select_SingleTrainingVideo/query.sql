SELECT 
	video_path, description
FROM modules
WHERE id = :moduleID 