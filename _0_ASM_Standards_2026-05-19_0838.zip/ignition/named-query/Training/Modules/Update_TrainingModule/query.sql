UPDATE modules
SET {myColumn} = :myValue
WHERE id = :index