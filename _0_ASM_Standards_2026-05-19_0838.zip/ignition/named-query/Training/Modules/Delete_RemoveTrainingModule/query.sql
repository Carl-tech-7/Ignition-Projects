DELETE FROM modules
WHERE id = :index
