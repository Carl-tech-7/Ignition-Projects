import os
import java.lang.System

def osDetect():
	os_name = java.lang.System.getProperty("os.name").lower()
	
	if "win" in os_name:
	    return "Windows"
	elif "nix" in os_name or "nux" in os_name or "aix" in os_name:
	    return "Linux"
	return "Unknown"

def loadedPing(ipAddress,Debug=0):	
	osName = osDetect()
	
	# Construct ping request according to OS detected
	if osName == "Windows":
		request = "ping %s -l 50000" % ipAddress
	elif osName == "Linux":
		request = "ping -c 4 -s 50000 %s" % ipAddress
	pingResult = os.popen(request).read()	
	
	# If debug enabled, print the pingResult to log
	if Debug: 	
		print request
		print pingResult
    
    # Get key results from ping
	if osName == "Windows":
		if "Average =" in pingResult:
			avePing = int(pingResult.split("Average = ")[1].split("ms")[0])
			netFlt = False
			packetLoss = int(pingResult.split("(")[1].split(" loss")[0].split("%")[0])
		else:
			avePing = 0
			netFlt = True
			packetLoss = int(pingResult.split("(")[1].split(" loss")[0].split("%")[0])
	elif osName == "Linux":
		if "rtt min/avg/max" in pingResult:
			statsLine = pingResult.split("rtt min/avg/max")[1]
			avg = statsLine.split('=')[1].split('/')[1]
			avePing = int(avg)
			netFlt = False
			packetLoss = int(pingResult.split("received, ")[1].split("%")[0])
		else:
			avePing = 0
			netFlt = True
			packetLoss = int(pingResult.split("received, ")[1].split("%")[0])
	return {"avePing":avePing,"netFault":netFlt, "packetLoss":packetLoss}

def ping(ipAddress,Debug=0):	
	osName = osDetect()
	
	# Construct ping request according to OS detected
	if osName == "Windows":
		request = "ping %s" % ipAddress
	elif osName == "Linux":
		request = "ping -c 4 %s" % ipAddress
	pingResult = os.popen(request).read()
	
	# If debug enabled, print the pingResult to log
	if Debug:
		print request
		print pingResult
    
    # Get key results from ping
	if osName == "Windows":
		if "Average =" in pingResult:
			avePing = int(pingResult.split("Average = ")[1].split("ms")[0])
			netFlt = False
			packetLoss = int(pingResult.split("(")[1].split(" loss")[0].split("%")[0])
		else:
			avePing = 0
			netFlt = True
			packetLoss = int(pingResult.split("(")[1].split(" loss")[0].split("%")[0])
	elif osName == "Linux":
		if "rtt min/avg/max" in pingResult:
			statsLine = pingResult.split("rtt min/avg/max")[1]
			avg = statsLine.split('=')[1].split('/')[1]
			avePing = int(avg)
			netFlt = False
			packetLoss = int(pingResult.split("received, ")[1].split("%")[0])
		else:
			avePing = 0
			netFlt = True
			packetLoss = int(pingResult.split("received, ")[1].split("%")[0])
	return {"avePing":avePing,"netFault":netFlt, "packetLoss":packetLoss}