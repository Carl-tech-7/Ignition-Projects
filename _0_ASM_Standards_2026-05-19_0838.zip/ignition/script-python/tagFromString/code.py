def getTypeBool(tagString):
	#
	return type(tagString) == bool
	
def getBitNumber(tagString):
	
	charArray = str(tagString).split(".")
	charCount = len(charArray)
		
	if charCount > 1:
		return charArray[charCount-1]
	else:
		return 0
		
def getSetValue(tagString):
	
	charArray = str(tagString).split("-")
	charCount = len(charArray)
		
	if charCount > 1:
		return charArray[charCount-1]
	else:
		return 0
		
def getTagPath(tagString):
		
	charArray = str(tagString).split(".")
	charCount = len(charArray)
	
	string = charArray[0]
	
	for count in range(1,charCount-1):
		string = string + "." + charArray[count]
	
	if not self.custom.tagCmdOff.typeBool:
		return string
	else:
		return ""