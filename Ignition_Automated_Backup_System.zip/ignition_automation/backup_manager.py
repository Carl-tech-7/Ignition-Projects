"""Safe Windows Ignition backup collector and Git publisher (Python 3.9+ stdlib)."""
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
CONFIG = HERE / 'config.json'

def run(cmd, cwd, log):
    p = subprocess.run(cmd, cwd=str(cwd), text=True, stdout=subprocess.PIPE,
                       stderr=subprocess.STDOUT, encoding='utf-8', errors='replace')
    log('$ ' + ' '.join(cmd) + '\n' + p.stdout.strip())
    if p.returncode:
        raise RuntimeError(f'Command failed ({p.returncode}): {cmd[0]} {cmd[1]}')
    return p.stdout.strip()

def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1024*1024), b''):
            h.update(block)
    return h.hexdigest()

def safe_name(name):
    return ''.join(c if c.isalnum() or c in '._- ' else '_' for c in name).strip(' .') or 'Unnamed'

def main():
    cfg = json.loads(CONFIG.read_text(encoding='utf-8'))
    repo = Path(cfg['repository'])
    if not (repo / '.git').exists():
        raise RuntimeError('Configured repository has no .git directory: ' + str(repo))
    logs = repo / 'logs'
    logs.mkdir(exist_ok=True)
    logfile = logs / (dt.date.today().isoformat() + '.log')
    def log(message):
        line = f'[{dt.datetime.now().isoformat(timespec="seconds")}] {message}'
        print(line, flush=True)
        with logfile.open('a', encoding='utf-8') as f:
            f.write(line + '\n')
    lock = repo / '.state' / 'running.lock'
    lock.parent.mkdir(exist_ok=True)
    if lock.exists():
        raise RuntimeError('Another run or stale lock exists: ' + str(lock))
    lock.write_text(str(os.getpid()), encoding='ascii')
    try:
        log('Starting backup scan; no Gateway/PLC writes are performed.')
        # Check remote before modifying repo. Never merge automatically.
        run(['git', 'rev-parse', '--show-toplevel'], repo, log)
        run(['git', 'fetch', cfg['remote']], repo, log)
        branch = run(['git', 'branch', '--show-current'], repo, log)
        if branch != cfg['branch']:
            raise RuntimeError('Wrong branch: ' + branch)
        aheadbehind = run(['git','rev-list','--left-right','--count',
                           f"{cfg['remote']}/{cfg['branch']}...HEAD"], repo, log)
        behind, ahead = [int(x) for x in aheadbehind.split()]
        if behind:
            raise RuntimeError(f'Remote has {behind} newer commits. Resolve in GitHub Desktop first; no force push.')
        status = run(['git','status','--porcelain'], repo, log)
        if status:
            log('Existing uncommitted changes detected; leaving them untouched. Commit/review them before scheduled runs.')
            raise RuntimeError('Working tree is not clean')
        state_path = repo / '.state' / 'project_scan.json'
        try:
            state = json.loads(state_path.read_text(encoding='utf-8'))
        except (FileNotFoundError, ValueError):
            state = {'missing_counts': {}}
        project_inbox = Path(cfg['project_export_inbox'])
        seen = set()
        changed = []
        if project_inbox.is_dir():
            inputs = sorted((p for p in project_inbox.rglob('*.zip') if p.is_file()), key=lambda p: str(p))
            grouped = {}
            for p in inputs:
                rel = p.relative_to(project_inbox)
                name = safe_name(rel.parts[0] if len(rel.parts) > 1 else p.stem)
                grouped.setdefault(name, []).append(p)
            for name, files in grouped.items():
                source = max(files, key=lambda p: p.stat().st_mtime)
                seen.add(name)
                if source.stat().st_size > int(cfg['max_git_file_mb'])*1024*1024:
                    log(f'SKIPPED oversized project ZIP: {source}')
                    continue
                dest_dir = repo / 'Projects' / name
                dest_dir.mkdir(parents=True, exist_ok=True)
                dest = dest_dir / 'latest.zip'
                if not dest.exists() or digest(source) != digest(dest):
                    if cfg['project_zip_to_git']:
                        shutil.copy2(source, dest)
                        changed.append(f'UPDATED PROJECT {name} from {source.name}')
                else:
                    log(f'SAME BACKUP: {name} (SHA256 identical)')
                notes = dest_dir / 'Project_Notes.txt'
                if not notes.exists():
                    notes.write_text(f'Project: {name}\nNotes (edit this file):\n', encoding='utf-8')
                    changed.append(f'NEW NOTES {name}')
            previous = set(state.get('known_projects', []))
            missing = state.get('missing_counts', {})
            for name in previous - seen:
                missing[name] = missing.get(name, 0) + 1
                if missing[name] >= int(cfg['missing_project_grace_runs']):
                    log(f'MISSING PROJECT SOURCE: {name} (not deleting any backups)')
            for name in seen:
                missing.pop(name, None)
            state = {'known_projects': sorted(previous | seen), 'missing_counts': missing}
            state_path.write_text(json.dumps(state, indent=2), encoding='utf-8')
        else:
            log('WARNING: Project export inbox missing; project scan skipped, no deletion inferred.')
        gateway_inbox = Path(cfg['gateway_backup_inbox'])
        if gateway_inbox.is_dir():
            dest_dir = repo / 'GatewayBackups'
            dest_dir.mkdir(exist_ok=True)
            for source in gateway_inbox.glob('*.gwbk'):
                dest = dest_dir / source.name
                if not dest.exists() or digest(source) != digest(dest):
                    shutil.copy2(source, dest)
                    log('LOCAL-ONLY Gateway backup copied: ' + source.name)
                else:
                    log('SAME GATEWAY BACKUP: ' + source.name)
        else:
            log('WARNING: Gateway inbox missing; Gateway copy skipped.')
        # Stage only explicitly approved project folder and notes. Never stage GatewayBackups.
        if (repo / 'Projects').exists():
            run(['git', 'add', '-A', '--', 'Projects'], repo, log)
        staged = run(['git','diff','--cached','--name-status'], repo, log)
        if staged:
            log('CHANGES:\n' + staged)
            message = 'Automated Ignition project backups ' + dt.date.today().isoformat()
            run(['git','commit','-m',message], repo, log)
        else:
            log('No new changes; same backup or nothing to commit.')
        # Do not push until all local operations succeeded.
        run(['git','push',cfg['remote'],cfg['branch']], repo, log)
        log('SUCCESS: Backup scan and GitHub sync completed.')
    finally:
        lock.unlink(missing_ok=True)

if __name__ == '__main__':
    try:
        main()
    except Exception as exc:
        print('ERROR:', exc, file=sys.stderr)
        sys.exit(1)
