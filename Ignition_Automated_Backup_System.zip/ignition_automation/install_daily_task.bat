@echo off
setlocal
cd /d "%~dp0"
set "TASKNAME=Ignition GitHub Backup Manager"
set "RUN=%~dp0backup_to_github.bat"
echo Creating daily 18:00 task for current Windows user...
schtasks /Create /F /SC DAILY /ST 18:00 /TN "%TASKNAME%" /TR "\"%RUN%\" --scheduled"
if errorlevel 1 (
 echo ERROR: Task could not be created. Run this file with appropriate permissions.
) else (
 echo Task created. Test it with: schtasks /Run /TN "%TASKNAME%"
)
pause
