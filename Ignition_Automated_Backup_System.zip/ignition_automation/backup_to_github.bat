@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>&1
if not errorlevel 1 (
  py -3 "%~dp0backup_manager.py" %*
) else (
  python "%~dp0backup_manager.py" %*
)
set "EXITCODE=%ERRORLEVEL%"
if /I not "%~1"=="--scheduled" pause
exit /b %EXITCODE%
